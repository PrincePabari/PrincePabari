﻿using BAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Contact
{
    public partial class OwnerContact : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region check valid user
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion check valid user

            #region PostBack
            if (!Page.IsPostBack)
            {
                    FillGridView();
            }
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill Gridview
        protected void FillGridView()
        {
            ContactBAL balContact = new ContactBAL();
            DataTable dt = new DataTable();
            dt = balContact.SelectAll(Convert.ToInt32(Session["OwnerID"].ToString().Trim()));
            if (dt.Rows.Count > 0)
            {
                gvContact.DataSource = dt;
                gvContact.DataBind();
            }
        }
        #endregion Fill GridView

        #region Delete By ContactID
        private void DeleteByContactID(SqlInt32 ContactID)
        {
            ContactBAL balContact = new ContactBAL();
            if(balContact.DeleteByPK(Convert.ToInt32(Session["OwnerID"].ToString()),ContactID))
            {
                lblError.Text = "Data Deleted Successfully";
            }
            else
            {
                lblError.Text = balContact.Message;
            }
        }
        #endregion Delete By ContactID

        #region Row Command
        protected void gvContact_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "DeleteCommand")
            {
                if(e.CommandArgument != null)
                {
                    DeleteByContactID(Convert.ToInt32(e.CommandArgument.ToString().Trim()));
                    FillGridView();
                }
            }
        }
        #endregion Row Command

        #region Search
        protected void Search(object sender, EventArgs e)
        {
            if(txtSearch.Text.Trim() != "")
            {
                ContactBAL balContact = new ContactBAL();
                gvContact.DataSource = balContact.SearchContact(Convert.ToString(txtSearch.Text.Trim()));
                gvContact.DataBind();
            }
            else
            {
                    FillGridView();
            }
        }
        #endregion Search
    }
}