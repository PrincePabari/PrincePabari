﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Contact
{
    public partial class Contact : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ClientID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
        }
        #endregion Load Event

        #region Submit Button
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            #region Server Side Validation
            string strMessage = "";

            if (txtName.Text.Trim() == "")
                strMessage = "-Enter Name<br />";

            if (txtEmail.Text.Trim() == "")
                strMessage = "-Enter Email<br />";

            if (txtComment.Text.Trim() == "")
                strMessage = "-Enter Comment<br />";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            #endregion Server Side Validation

            #region Read Data
            ContactENT entContact = new ContactENT();

            if (txtName.Text.Trim() != "")
                entContact.Name = txtName.Text.Trim();

            if (txtEmail.Text.Trim() != "")
                entContact.Email = txtEmail.Text.Trim();

            if (txtComment.Text.Trim() != "")
                entContact.Comment = txtComment.Text.Trim();

            if (Session["ClientID"] != null)
                entContact.ClientID = Convert.ToInt32(Session["ClientID"].ToString().Trim());

            #endregion Read Data

            #region Objects And Methods
            ContactBAL balContact = new ContactBAL();
            if (balContact.Insert(entContact))
            {
                lblError.Text = "Data Inserted Successfully.";
                ClearControls();
            }
            else
            {
                lblError.Text = balContact.Message;
            }
            #endregion Objects And Methods
        }
        #endregion Submit Button

        #region Clear Controls
        private void ClearControls()
        {
            txtName.Text = "";
            txtEmail.Text = "";
            txtComment.Text = "";
            txtName.Focus();
        }
        #endregion Clear Controls
    }
}