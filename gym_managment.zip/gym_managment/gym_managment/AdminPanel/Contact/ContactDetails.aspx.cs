﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Contact
{
    public partial class ContactDetails : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region check valid user
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion check valid user

            #region PostBack
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["ContactID"] == null)
                {
                    lblError.Text = "Invalid ID";
                }
                else
                {
                    FillContactForm(Convert.ToInt32(Request.QueryString["ContactID"].ToString().Trim()));
                    lblWelcome.Text = "Details of Contact | Contact ID = " + Request.QueryString["ContactID"].ToString().Trim();
                }
            }
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill Contact Form
        private void FillContactForm(SqlInt32 ContactID)
        {
            ContactBAL balContact = new ContactBAL();
            ContactENT entContact = new ContactENT();
            entContact = balContact.SelectByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString()), ContactID);
            if (!entContact.ContactID.IsNull)
                lblID.Text = entContact.ContactID.ToString().Trim();

            if (!entContact.Name.IsNull)
                lblContact.Text = entContact.Name.ToString().Trim();

            if (!entContact.Email.IsNull)
                lblEmailID.Text = entContact.Email.ToString().Trim();

            if (!entContact.Comment.IsNull)
                lblComment.Text = entContact.Comment.ToString().Trim();

            if (!entContact.TrainerID.IsNull)
            {
                lblTrainerID.Text = entContact.TrainerID.ToString().Trim();
            }
            else
            {
                lblTrainer.Visible = false;
                lblTrainerID.Visible = false;
            }

            if (!entContact.ClientID.IsNull)
            {
                lblClient.Text = entContact.ClientID.ToString().Trim();
            }
            else
            {
                lblClient.Visible = false;
                lblClientID.Visible = false;
            }
        }
        #endregion Fill Contact Form

        #region Delete Button
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            ContactBAL balContact = new ContactBAL();
            if (balContact.DeleteByPK(Convert.ToInt32(Session["OwnerID"].ToString()), Convert.ToInt32(lblID.Text.Trim())))
            {
                Response.Redirect("~/AdminPanel/Contact/OwnerContact.aspx");
            }
            else
            {
                lblError.Text = balContact.Message;
            }
        }
        #endregion Delete Button

        #region Back Button
        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Contact/OwnerContact.aspx");
        }
        #endregion Back Button

    }
}