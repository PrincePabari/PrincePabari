﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Owner
{
    public partial class OwnerLogin : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion Load Event

        #region Cancel Button
        protected void lbCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Default.aspx");
        }
        #endregion Cancel Button

        #region Login Button
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            #region Local Variables
            string strMessage = "";
            SqlString UserName = SqlString.Null;
            SqlString Password = SqlString.Null;
            #endregion Local Variables

            #region Server Side Validation
            if (txtOwnerName.Text.Trim() == "")
                strMessage = "-Enter UserName <br />";

            if (txtPassword.Text.Trim() == "")
                strMessage = "-Enter UserName <br />";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            #endregion Server Side Validation

            #region Read Data
            if (txtOwnerName.Text.Trim() != "")
                UserName = txtOwnerName.Text.Trim();

            if (txtPassword.Text.Trim() != "")
                Password = txtPassword.Text.Trim();
            #endregion Read Data

            #region Objects and Methods
            OwnerBAL balOwner = new OwnerBAL();
            OwnerENT entOwner = new OwnerENT();

            entOwner = balOwner.SelectForLogin(UserName, Password);
            if (balOwner.Message == null)
            {
                if (!entOwner.OwnerID.IsNull)
                    Session["OwnerID"] = entOwner.OwnerID;
                else
                {
                    lblError.Text = "Please check Username and Password !";
                    return;
                }
                if (!entOwner.OwnerName.IsNull)
                    Session["OwnerName"] = entOwner.OwnerName;
                else
                {
                    lblError.Text = "Please check Username and Password !";
                    return;
                }
                Response.Redirect("~/AdminPanel/Owner/Home.aspx");
            }
            else
            {
                lblError.Text = balOwner.Message;
            }
            #endregion Objects and Methods
        }
        #endregion Login Button
    }
}