﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Owner
{
    public partial class Home : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["OwnerID"] == null)
                Response.Redirect("~/Content/AdminPanel/Login/Default.aspx");

            if (!Page.IsPostBack)
            {
                FillHome();
            }
        }
        #endregion Load Event

        #region Fill Home
        private void FillHome()
        {
            OwnerBAL balOwner = new OwnerBAL();
            OwnerENT entOwner = new OwnerENT();
            entOwner = balOwner.SelectByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()));

            if (!entOwner.OwnerID.IsNull)
                lblID.Text = entOwner.OwnerID.ToString().Trim();

            if (!entOwner.OwnerName.IsNull)
                lblOwner.Text = entOwner.OwnerName.ToString().Trim();

            if (!entOwner.UserName.IsNull)
                lblName.Text = entOwner.UserName.ToString().Trim();

            if (!entOwner.MobileNo.IsNull)
                lblNo.Text = entOwner.MobileNo.ToString().Trim();

        }
        #endregion Fill Home
    }
}