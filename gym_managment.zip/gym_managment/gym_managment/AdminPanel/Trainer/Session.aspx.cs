﻿using BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class Session : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check Valid User
            if (Session["TrainerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion Check Valid User

            #region PostBack
            if (!Page.IsPostBack)
                FillgvSession();
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill gridview
        private void FillgvSession()
        {
            SessionBAL balSession = new SessionBAL();
            DataTable dt = new DataTable();
            dt = balSession.SelectAll(Convert.ToInt32(Session["TrainerID"].ToString()));
            gvSession.DataSource = dt;
            gvSession.DataBind();
        }
        #endregion Fill gridview

        #region Add Button
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Trainer/AddSession.aspx");
        }
        #endregion Add Button

        #region Delete Row Command
        protected void gvSession_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteCommand")
            {
                if (e.CommandArgument != null)
                {
                    DeleteSession(Convert.ToInt32(e.CommandArgument));
                    FillgvSession();
                }
            }
        }
        #endregion Delete Row Command

        #region Delete Session
        private void DeleteSession(SqlInt32 SessionID)
        {
            SessionBAL balSession = new SessionBAL();
            if (balSession.DeleteSession(Convert.ToInt32(Session["TrainerID"].ToString().Trim()), SessionID))
            {
                lblError.Text = "Data Deleted Successfully.";
            }
            else
            {
                lblError.Text = balSession.Message;
            }
        }
        #endregion Delete Session

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            if (gvPrevious.Visible)
                gvPrevious.Visible = false;
            else
            {
                gvPrevious.Visible = true;
                SessionBAL balSession = new SessionBAL();
                DataTable dt = new DataTable();
                dt = balSession.SelectAllPrevios(Convert.ToInt32(Session["TrainerID"].ToString()));
                gvPrevious.DataSource = dt;
                gvPrevious.DataBind();
            }
        }

        #region Delete Row Command in Previos Gridview
        protected void gvPrevious_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteCommand")
            {
                if (e.CommandArgument != null)
                {
                    DeleteSession(Convert.ToInt32(e.CommandArgument));
                    FillgvSession();
                }
            }
        }
        #endregion Delete Row Command in Previos Gridview
    }
}