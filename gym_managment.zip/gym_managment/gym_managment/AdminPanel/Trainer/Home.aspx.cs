﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class Home : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region check valid user
            if (Session["TrainerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");

            if (Session["TrainerName"] != null)
                lblWelcome.Text = "Welcome" + " " + Session["TrainerName"].ToString().Trim();
            #endregion check valid user

            #region PostBack
            FillHome();
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill Home
        private void FillHome()
        {
            TrainerBAL balTrainer = new TrainerBAL();
            TrainerENT entTrainer = new TrainerENT();
            SqlInt32 OnwerID = Convert.ToInt32(1);
            if(Session["TrainerID"] != null)
                entTrainer = balTrainer.SelectByPKOwnerID(Convert.ToInt32(Session["TrainerID"].ToString()), OnwerID);

            if (!entTrainer.TrainerID.IsNull)
                lblID.Text = entTrainer.TrainerID.ToString().Trim();

            if (!entTrainer.TrainerName.IsNull)
                lblTrainer.Text = entTrainer.TrainerName.ToString().Trim();

            if (!entTrainer.UserName.IsNull)
                lblName.Text = entTrainer.UserName.ToString().Trim();

            if (!entTrainer.MobileNo.IsNull)
                lblNo.Text = entTrainer.MobileNo.ToString().Trim();

            if (!entTrainer.Address.IsNull)
                lblAddress.Text = entTrainer.Address.ToString().Trim();

            if (!entTrainer.ExperienceYears.IsNull)
            {
                lblExpYear.Text = entTrainer.ExperienceYears.ToString().Trim();
            }
            else
            {
                lblExperience.Visible = false;
                lblExpYear.Visible = false;
            }
            if (!entTrainer.Salary.IsNull)
            {
                lblTSalary.Text = entTrainer.Salary.ToString().Trim();
            }
            else
            {
                lblSalary.Visible = false;
                lblTSalary.Visible = false;
            }
            if (!entTrainer.SpecialistOf.IsNull)
            {
                lblSpecialistOf.Text = entTrainer.SpecialistOf.ToString().Trim();
            }
            else
            {
                lblSpecial.Visible = false;
                lblSpecialistOf.Visible = false;
            }
            if (!entTrainer.PhotoPath.IsNull)
            {
                imgTrainer.ImageUrl = entTrainer.PhotoPath.ToString().Trim();
            }
            else
            {
                lblPhoto.Visible = false;
                imgTrainer.Visible = false;
            }
        }
        #endregion Fill Home
    }
}