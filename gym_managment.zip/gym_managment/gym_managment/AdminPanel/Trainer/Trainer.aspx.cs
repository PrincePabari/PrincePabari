﻿using BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class Trainer : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check Valid User
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");

            #endregion Check Valid User

            #region Post Back
            if (!Page.IsPostBack)
            {
                ViewState["sortexp"] = "";
                ViewState["orderby"] = "ASC";
                FillGridView("");
            }
            #endregion Post Back
        }
        #endregion Load Event

        #region Fill GridView
        private void FillGridView(string sortexp)
        {
            TrainerBAL balTrainer = new TrainerBAL();
            DataTable dt = new DataTable();
            dt = balTrainer.SelectAll(Convert.ToInt32(Session["OwnerID"].ToString().Trim()));
            DataView DV = dt.DefaultView;
            if (sortexp != "")
                DV.Sort = sortexp;

            gvTrainer.DataSource = DV;
            gvTrainer.DataBind();
        }

        #endregion Fill GridView

        #region Add Button
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Trainer/AddEditTrainer.aspx");
        }
        #endregion Add Button

        #region gvTrainer Row Command
        protected void gvTrainer_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteCommand")
            {
                if (e.CommandArgument != null)
                {
                    DeleteTrainer(Convert.ToInt32(e.CommandArgument.ToString().Trim()));
                }
            }
        }
        #endregion gvTrainer Row Command

        #region Delete Trainer
        private void DeleteTrainer(SqlInt32 TrainerID)
        {
            TrainerBAL balTrainer = new TrainerBAL();
            if (balTrainer.DeleteByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()), TrainerID))
            {
                lblError.Text = "Data Deleted Successfully.";
            }
            else
            {
                lblError.Text = balTrainer.Message;
            }
        }
        #endregion Delete Trainer

        #region Sorting
        protected void gvTrainer_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (ViewState["orderby"].ToString() == "ASC")
            {
                ViewState["orderby"] = "DESC";
                ViewState["sortexp"] = e.SortExpression + " DESC";
            }
            else
            {
                ViewState["orderby"] = "ASC";
                ViewState["sortexp"] = e.SortExpression + " ASC";
            }
            FillGridView(ViewState["sortexp"].ToString());
        }
        #endregion Sorting

        #region Search
        protected void Search(object sender, EventArgs e)
        {
            if (txtSearch.Text.Trim() != "")
            {
                TrainerBAL balTrainer = new TrainerBAL();
                gvTrainer.DataSource = balTrainer.SearchTrainer(Convert.ToString(txtSearch.Text.Trim()));
                gvTrainer.DataBind();
            }
            else
            {
                FillGridView("");
            }
        }
        #endregion Search

    }
}