﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class AddEditTrainer : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check Valid User
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");

            #endregion Check Valid User

            #region Request check
            if (Request.QueryString["TrainerID"] == null)
            {
                lblWelcome.Text = "Trainer Enrollment";
            }
            else
            {
                lblWelcome.Text = "Update details | TrainerID=" + " " + Request.QueryString["TrainerID"].ToString().Trim();
                FillTrainerForm(Convert.ToInt32(Request.QueryString["TrainerID"].ToString().Trim()));
            }
            #endregion Request check
        }
        #endregion Load Event

        #region Fill Trainer
        private void FillTrainerForm(SqlInt32 TrainerID)
        {
            TrainerBAL balTrainer = new TrainerBAL();
            TrainerENT entTrainer = new TrainerENT();
            entTrainer = balTrainer.SelectByPKOwnerID(TrainerID, Convert.ToInt32(Session["OwnerID"].ToString().Trim()));

            if (!entTrainer.TrainerName.IsNull)
                txtTrainerName.Text = entTrainer.TrainerName.ToString().Trim();

            if (!entTrainer.UserName.IsNull)
                txtTUserName.Text = entTrainer.UserName.ToString().Trim();

            if (!entTrainer.MobileNo.IsNull)
                txtTMobileNo.Text = entTrainer.MobileNo.ToString().Trim();

            if (!entTrainer.ExperienceYears.IsNull)
                txtExperience.Text = entTrainer.ExperienceYears.ToString().Trim();

            if (!entTrainer.Address.IsNull)
                txtTAddress.Text = entTrainer.Address.ToString().Trim();

            if (!entTrainer.Salary.IsNull)
                txtSalary.Text = entTrainer.Salary.ToString().Trim();

            if (!entTrainer.SpecialistOf.IsNull)
                txtTrainerName.Text = entTrainer.SpecialistOf.ToString().Trim();

            if (!entTrainer.Password.IsNull)
                txtTPassword.Text = entTrainer.Password.ToString().Trim();
        }

        #endregion Fill Trainer

        #region Save Button
        protected void BtnTSave_Click(object sender, EventArgs e)
        {
            #region Local Variable
            string strMessage = "";
            string strFileLocationToSave = "";
            string strPhysicalPath = "";
            #endregion Local Variable

            #region Upload File
            if (fuTrainerPhoto.HasFiles)
            {
                strFileLocationToSave += "~/Content/UploadedData/Trainer/";
                strPhysicalPath += Server.MapPath(strFileLocationToSave);
                strPhysicalPath += fuTrainerPhoto.FileName;
                if (File.Exists(strPhysicalPath))
                {
                    File.Delete(strPhysicalPath);
                }
                fuTrainerPhoto.SaveAs(strPhysicalPath);
                strFileLocationToSave += fuTrainerPhoto.FileName;
            }
            #endregion Upload File

            #region server side validation
            if (txtTrainerName.Text.Trim() == "")
                strMessage += "-Enter Trainer Name<br />";

            if (txtTUserName.Text.Trim() == "")
                strMessage += "-Enter User Name<br />";

            if (txtTPassword.Text.Trim() == "")
                strMessage += "-Enter Password<br />";

            if (txtTAddress.Text.Trim() == "")
                strMessage += "-Enter Address<br />";

            if (txtTMobileNo.Text.Trim() == "")
                strMessage += "Enter Mobile Number<br />";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            #endregion server side validation

            #region Read Data
            TrainerENT entTrainer = new TrainerENT();
            if (txtTrainerName.Text.Trim() != "")
                entTrainer.TrainerName = txtTrainerName.Text.Trim();

            if (txtTUserName.Text.Trim() != "")
                entTrainer.UserName = txtTUserName.Text.Trim();

            if (txtTPassword.Text.Trim() != "")
                entTrainer.Password = txtTPassword.Text.Trim();

            if (txtTMobileNo.Text.Trim() != "")
                entTrainer.MobileNo = txtTMobileNo.Text.Trim();

            if (txtTAddress.Text.Trim() != "")
                entTrainer.Address = txtTAddress.Text.Trim();

            if (txtSpecialistOf.Text.Trim() != "")
                entTrainer.SpecialistOf = txtSpecialistOf.Text.Trim();

            if (txtExperience.Text.Trim() != "")
                entTrainer.ExperienceYears = Convert.ToInt32(txtExperience.Text.Trim());

            if (txtSalary.Text.Trim() != "")
                entTrainer.Salary = txtSalary.Text.Trim();

            if (strFileLocationToSave.Trim() != "")
                entTrainer.PhotoPath = strFileLocationToSave.Trim();

            entTrainer.OwnerID = Convert.ToInt32(Session["OwnerID"].ToString().Trim());
            #endregion Read Data

            #region Object and Method
            TrainerBAL balTrainer = new TrainerBAL();
            if (Request.QueryString["TrainerID"] == null)
            {
                if (balTrainer.InsertByOwnerID(entTrainer))
                {
                    lblError.Text = "Data Inserted Successfully.";
                }
                else
                {
                    lblError.Text = balTrainer.Message;
                }
            }
            else
            {
                entTrainer.TrainerID = Convert.ToInt32(Request.QueryString["TrainerID"]);
                if(balTrainer.UpdateOwner(entTrainer))
                {
                    Response.Redirect("~/AdminPanel/Trainer/Trainer.aspx");
                }
                else
                {
                    lblError.Text = balTrainer.Message;
                }
            }
            #endregion Object and Method
        }
        #endregion Save Button

        #region Cancel Button
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Trainer/Trainer.aspx");
        }
        #endregion Cancel Button
    }
}