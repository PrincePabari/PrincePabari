﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class AddSession : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check valid user
            if (Session["TrainerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion Check valid user
        }
        #endregion Load Event

        #region Save Button
        protected void BtnTSave_Click(object sender, EventArgs e)
        {
            #region Local Variables
            string starttime = "";
            string endtime = "";
            string message = "";
            SqlInt32 ClientID = SqlInt32.Null;
            #endregion Local Variables

            #region Date Computing
            if (txtStartTime.Text.Trim() != "")
                starttime += txtStartTime.Text.Trim();

            if (txtEndTime.Text.Trim() != "")
                endtime += txtEndTime.Text.Trim();

            if (ddlStartHour.SelectedIndex > 0)
                starttime += " " + ddlStartHour.SelectedValue;

            if (ddlStartMinute.SelectedIndex > 0)
                starttime += ":" + ddlStartMinute.SelectedValue + ":00";

            if (ddlEndHour.SelectedIndex > 0)
                endtime += " " + ddlEndHour.SelectedValue;

            if (ddlEndMinutes.SelectedIndex > 0)
                endtime += ":" + ddlEndMinutes.SelectedValue + ":00";
            #endregion Date Computing

            #region Server Side Validation
            if (txtSession.Text.Trim() == "")
                message += "Enter Session !";

            if (txtStartTime.Text.Trim() == "")
                message += "Enter Start date !";

            if (txtEndTime.Text.Trim() == "")
                message += "Enter End date !";

            if (ddlStartHour.SelectedIndex < 0)
                message += "select Start Hour !";

            if (ddlStartMinute.SelectedIndex < 0)
                message += "select Start minutes !";

            if (ddlEndHour.SelectedIndex < 0)
                message += "select End Hour !";

            if (ddlEndMinutes.SelectedIndex < 0)
                message += "select End minutes !";

            if (Convert.ToDateTime(txtStartTime.Text.Trim()) > Convert.ToDateTime(txtEndTime.Text.Trim()))
            {
                message += "Start date and End date is not in valid format !";
            }
            else
            {
                if (ddlStartHour.SelectedIndex > ddlEndHour.SelectedIndex)
                    message += "Start Hour and End Hour is not in valid format !";

                if(ddlStartHour.SelectedIndex == ddlEndHour.SelectedIndex)
                {
                    if (ddlStartMinute.SelectedIndex > ddlEndMinutes.SelectedIndex)
                        message += "Start minutes and end minutes is not in valid format !";
                }
            }
            if (Convert.ToDateTime(starttime.Trim()) < DateTime.Now || Convert.ToDateTime(endtime.Trim()) < DateTime.Now)
                message += "Date is not Valid !";

            if (message.Trim() != "")
            {
                lblError.Text = message.Trim();
                return;
            }
            #endregion Server Side Validation

            #region Read Data
            SessionENT entSession = new SessionENT();
            if (txtSession.Text.Trim() != "")
                entSession.Session = txtSession.Text.Trim();

            if (starttime.Trim() != "")
                entSession.StartTime = Convert.ToDateTime(starttime.Trim());

            if (endtime.Trim() != "")
                entSession.EndTime = Convert.ToDateTime(endtime.Trim());

            entSession.ClientID = ClientID;
            entSession.TrainerID = Convert.ToInt32(Session["TrainerID"].ToString().Trim());
            #endregion Read Data

            #region Object and Method
            SessionBAL balSession = new SessionBAL();
            //lblStartTime.Text = entSession.StartTime.ToString();
            //lblEndTime.Text = entSession.EndTime.ToString();
            if (balSession.InsertSession(entSession))
            {
                lblError.Text = "Data Inserted Successfully.";
                txtSession.Text = "";
                ddlStartHour.SelectedIndex = 0;
                ddlEndHour.SelectedIndex = 0;
                ddlStartMinute.SelectedIndex = 0;
                ddlEndMinutes.SelectedIndex = 0;
            }
            else
            {
                lblError.Text = balSession.Message;
            }
            #endregion Object and Method
        }
        #endregion Save Button

        #region Cancel Button
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Trainer/Session.aspx");
        }
        #endregion Cancel Button
    }
}