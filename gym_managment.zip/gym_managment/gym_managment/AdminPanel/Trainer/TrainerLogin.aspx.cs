﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Trainer
{
    public partial class TrainerLogin : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion Load Event

        #region Login Button
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            #region Local Variables
            string strMessage = "";
            SqlString UserName = SqlString.Null;
            SqlString Password = SqlString.Null;
            #endregion Local Variables

            #region Server Side Validation
            if (txtUserName.Text.Trim() == "")
                strMessage = "-Enter UserName <br />";

            if (txtPassword.Text.Trim() == "")
                strMessage = "-Enter UserName <br />";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            #endregion Server Side Validation

            #region Read Data
            if (txtUserName.Text.Trim() != "")
                UserName = txtUserName.Text.Trim();

            if (txtPassword.Text.Trim() != "")
                Password = txtPassword.Text.Trim();
            #endregion Read Data

            #region Objects and Methods
            TrainerBAL balTrainer = new TrainerBAL();
            TrainerENT entTrainer = new TrainerENT();
            entTrainer = balTrainer.SelectForLogin(UserName, Password);
            if (balTrainer.Message == null)
            {
                if (!entTrainer.TrainerID.IsNull)
                    Session["TrainerID"] = entTrainer.TrainerID;
                else
                {
                    lblError.Text = "Please check Username and Password !";
                    return;
                }

                if (entTrainer.TrainerName != null)
                    Session["TrainerName"] = entTrainer.TrainerName;
                else
                    lblError.Text = "Please check Username and Password !";

                Response.Redirect("~/AdminPanel/Trainer/Home.aspx");
            }
            else
            {
                lblError.Text = balTrainer.Message;
            }
            #endregion Objects and Methods
        }
        #endregion Login Button

        #region Cancel Button
        protected void lbCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Default.aspx");
        }
        #endregion Cancel Button 
    }
}