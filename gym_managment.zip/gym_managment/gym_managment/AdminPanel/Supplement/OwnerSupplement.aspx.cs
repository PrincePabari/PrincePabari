﻿using BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Supplement
{
    public partial class OwnerSupplement : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check Valid User
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");

            #endregion Check Valid User

            #region PostBack
            if (!Page.IsPostBack)
            {
                ViewState["sortexp"] = "";
                ViewState["orderby"] = "";
                FillSupplementGV("");
            }
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill Grid View
        private void FillSupplementGV(string sortexp)
        {
            SupplementBAL balSupplement = new SupplementBAL();
            DataTable dt = new DataTable();
            dt = balSupplement.SelectAll();
            DataView DV = dt.DefaultView;
            if (sortexp != "")
                DV.Sort = sortexp;

            gvSupplement.DataSource = DV;
            gvSupplement.DataBind();
        }
        #endregion Fill Grid View

        #region Row Command
        protected void gvSupplement_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteCommand")
            {
                if (e.CommandArgument != null)
                {

                    DeleteSupplementID(Convert.ToInt32(e.CommandArgument.ToString().Trim()));
                    FillSupplementGV("");
                }
            }
        }
        #endregion Row Command

        #region Delete By SupplementID
        private void DeleteSupplementID(SqlInt32 SupplementID)
        {
            SupplementBAL balSupplement = new SupplementBAL();
            if (balSupplement.DeleteByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()),SupplementID))
            {
                lblError.Text = "Data Deleted Successfully";
            }
            else
            {
                lblError.Text = balSupplement.Message;
            }
        }
        #endregion Delete By SupplementID

        #region Add Button
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Supplement/AddEditSupplement.aspx");
        }
        #endregion Add Button

        #region Sorting
        protected void gvSupplement_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (ViewState["orderby"].ToString() == "ASC")
            {
                ViewState["orderby"] = "DESC";
                ViewState["sortexp"] = e.SortExpression + " DESC";
            }
            else
            {
                ViewState["orderby"] = "ASC";
                ViewState["sortexp"] = e.SortExpression + " ASC";
            }
            FillSupplementGV(ViewState["sortexp"].ToString());
        }
        #endregion Sorting

        #region Search
        protected void Search(object sender, EventArgs e)
        {
            if (txtSearch.Text.Trim() != "")
            {
                SupplementBAL balSupplement = new SupplementBAL();
                gvSupplement.DataSource = balSupplement.SearchSupp(Convert.ToString(txtSearch.Text.Trim()));
                gvSupplement.DataBind();
            }
            else
            {
                FillSupplementGV("");
            }
        }
        #endregion Search
    }
}