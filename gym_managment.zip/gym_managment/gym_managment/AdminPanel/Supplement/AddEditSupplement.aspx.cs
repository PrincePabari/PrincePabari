﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Supplement
{
    public partial class AddEditSupplement : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check Valid User
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");

            #endregion Check Valid User

            #region PostBack
            if (Request.QueryString["SupplementID"] == null)
            {
                lblWelcome.Text = "New Supplement";
            }
            else
            {
                lblWelcome.Text = "Update Supplement | Supplement ID = " + " " + Request.QueryString["SupplementID"].ToString().Trim();
                FillForm(Convert.ToInt32(Request.QueryString["SupplementID"].ToString().Trim()));
            }
            #endregion PostBack
        }
        #endregion Load Event

        #region Save Button CLick Event
        protected void btnTSave_Click(object sender, EventArgs e)
        {
            #region Local Variables
            string strMessage = "";
            string strLocationToSave = "";
            string strPhysicalPath = "";
            #endregion Local Variables

            #region Server Side Validation
            if (txtSupplementName.Text.Trim() == "")
                strMessage = "-Enter Name <br/>";

            if (txtPrice.Text.Trim() == "")
                strMessage = "-Enter Price <br/>";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            #endregion Server Side Validation

            #region Upload File
            if (fuSupplementPhoto.HasFiles)
            {
                strLocationToSave += "~/Content/UploadedData/Supplement/";
                strPhysicalPath += Server.MapPath(strLocationToSave);
                strPhysicalPath += fuSupplementPhoto.FileName;
                if (File.Exists(strPhysicalPath))
                {
                    File.Delete(strPhysicalPath);
                }
                fuSupplementPhoto.SaveAs(strPhysicalPath);
                strLocationToSave += fuSupplementPhoto.FileName;
            }
            #endregion Upload File

            #region Read Data
            SupplementENT entSupplement = new SupplementENT();

            if (txtSupplementName.Text.Trim() != "")
                entSupplement.SupplementName = txtSupplementName.Text.Trim();

            if (txtPrice.Text.Trim() != "")
                entSupplement.Price = txtPrice.Text.Trim();

            if (strLocationToSave.Trim() != "")
                entSupplement.PhotoPath = strLocationToSave.Trim();

            entSupplement.OwnerID = Convert.ToInt32(Session["OwnerID"].ToString().Trim());
            #endregion Read Data

            #region Object and Method
            SupplementBAL balSupplement = new SupplementBAL();

            if (Request.QueryString["SupplementID"] == null)
            {
                if (balSupplement.InsertSupplement(entSupplement))
                {
                    lblError.Text = "Data Inserted Successfully";
                }
                else
                {
                    lblError.Text = balSupplement.Message;
                }
            }
            else
            {
                    entSupplement.SupplementID = Convert.ToInt32(Request.QueryString["SupplementID"].ToString().Trim());

                if (balSupplement.UpdateSupplement(entSupplement))
                {
                    Response.Redirect("~/AdminPanel/Supplement/OwnerSupplement.aspx");
                }
                else
                {
                    lblError.Text = balSupplement.Message;
                }
            }
            #endregion Object and Method
        }
        #endregion Save Button CLick Event

        #region Cancel Button Click Event
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Supplement/OwnerSupplement.aspx");
        }
        #endregion Cancel Button Click Event

        #region Fill Supplement Form
        private void FillForm(SqlInt32 SupplementID)
        {
            SupplementBAL balSupplement = new SupplementBAL();
            SupplementENT entSupplement = new SupplementENT();
            entSupplement = balSupplement.SelectByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()), SupplementID);
            if (!entSupplement.SupplementName.IsNull)
                txtSupplementName.Text = entSupplement.SupplementName.ToString().Trim();

            if (!entSupplement.Price.IsNull)
                txtPrice.Text = entSupplement.Price.ToString().Trim();

        }
        #endregion Fill Supplement Form
    }
}