﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Supplement
{
    public partial class ClientSupplement : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region PostBack
            if (!Page.IsPostBack)
            {
                FillRepeater();
            }
            #endregion PostBack
        }
        #endregion Load Event

        #region Fill Supplement Repeater
        private void FillRepeater()
        {
            SupplementBAL balSupplement = new SupplementBAL();
            SupplementENT entSupplement = new SupplementENT();
            rptrSupplement.DataSource = balSupplement.SelectAll();
            rptrSupplement.DataBind();


            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    rptrSupplement = (from rw in dt.AsEnumerable()
            //                      select new SupplementENT()
            //                      {

            //                          SupplementID = Convert.ToInt32(rw["SupplementID"]),
            //                           SupplementName = Convert.ToString(rw["SupplementName"]),
            //                      }).ToList();
            //}
            //rptrSupplement.DataSource = dt;
            //rptrSupplement.DataBind();
            //#endregion Fill Supplement Repeater
        }
        #endregion Fill Supplement Repeater
    }
}