﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel
{
    public partial class Default : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion Load Event

        #region Owner Button
        protected void btnOwner_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Owner/OwnerLogin.aspx");
        }
        #endregion Owner Button

        #region Trainer Button
        protected void btnTrainer_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Trainer/TrainerLogin.aspx");
        }
        #endregion Trainer Button

        #region Client Button
        protected void btnClient_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Client/ClientLogin.aspx");
        }
        #endregion Client Button
    }
}