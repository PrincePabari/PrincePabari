﻿using BAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Client
{
    public partial class Client : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region check valid user
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion check valid user

            #region Postback
            if (!Page.IsPostBack)
            {
                ViewState["sortexp"] = "";
                ViewState["orderby"] = "ASC";
                FillGridView("");
            }
            #endregion Postback
        }
        #endregion Load Event

        #region Fill Grid View
        public void FillGridView(string sortexp)
        {
            ClientBAL balClient = new ClientBAL();
            DataTable dt = new DataTable();
            dt = balClient.SelectAll(Convert.ToInt32(Session["OwnerID"].ToString().Trim()));
            DataView DV = dt.DefaultView;
            if (sortexp != "")
                DV.Sort = sortexp;

                gvClient.DataSource = DV;
                gvClient.DataBind();
        }
        #endregion Fill Grid View

        #region Add Button
        protected void btnAdd_Click(object sender, EventArgs e)
        {

            Response.Redirect("~/AdminPanel/Client/AddEditClient.aspx");
        }
        #endregion Add Button

        #region GridView RowCommand
        protected void gvClient_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteCommand")
            {
                if (e.CommandArgument != null)
                {
                    DeleteByClientID(Convert.ToInt32(e.CommandArgument.ToString().Trim()));
                    FillGridView("");
                }
            }
        }
        #endregion GridView RowCommand

        #region Delete By ClientID
        private void DeleteByClientID(SqlInt32 ClientID)
        {
            ClientBAL balClient = new ClientBAL();
            if(balClient.DeleteByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()),ClientID))
            {
                lblError.Text = "Data Deleted Successfully.";
            }
            else
            {
                lblError.Text = balClient.Message;
            }
        }
        #endregion Delete By ClientID

        #region Sorting
        protected void gvClient_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (ViewState["orderby"].ToString() == "ASC")
            {
                ViewState["orderby"] = "DESC";
                ViewState["sortexp"] = e.SortExpression + " DESC";
            }
            else
            {
                ViewState["orderby"] = "ASC";
                ViewState["sortexp"] = e.SortExpression + " ASC";
            }
            FillGridView(ViewState["sortexp"].ToString());
        }
        #endregion Sorting

        #region Search
        protected void Search(object sender, EventArgs e)
        {
            if (txtSearch.Text.Trim() != "")
            {
                ClientBAL balClient = new ClientBAL();
                gvClient.DataSource = balClient.SearchClient(Convert.ToString(txtSearch.Text.Trim()));
                gvClient.DataBind();
            }
            else
            {
                FillGridView("");
            }
        }
        #endregion Search
    }
}