﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Client
{
    public partial class BMI : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Postback
            if (!Page.IsPostBack)
            {
                btnAdd.Enabled = false;
            }
            #endregion Postback

            #region check valid user
            if (Session["ClientID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion check valid user
        }
        #endregion Load Event

        #region Calculate BMi
        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            double h = 0, w = 0, bmi = 0;
            string strMessage = "";
            if (txtHeight.Text.Trim() == "")
                strMessage = "-Enter Height";

            if (txtWeight.Text.Trim() == "")
                strMessage = "-Enter Weight";

            if (strMessage.Trim() != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }
            if (txtHeight.Text.Trim() != "")
                h = Convert.ToDouble(txtHeight.Text.Trim());

            if (txtWeight.Text.Trim() != "")
                w = Convert.ToDouble(txtWeight.Text.Trim());

            h = h / 100;
            bmi = w / (h * h);
            txtBMI.Text = Convert.ToString(bmi);
            btnAdd.Enabled = true;
        }
        #endregion Calculate BMi

        #region Add Button
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtBMI.Text.Trim() != "")
            {
                ClientBAL balClient = new ClientBAL();
                ClientENT entClient = new ClientENT();
                entClient.BMI = Convert.ToDouble(txtBMI.Text.Trim());
                entClient.ClientID = Convert.ToInt32(Session["ClientID"]);

                if (balClient.UpdateBMI(entClient))
                {
                    lblError.Text = "BMI Updated Successfully.";
                }
                else
                {
                    lblError.Text = balClient.Message;
                }
            }
        }
        #endregion Add Button
    }
}