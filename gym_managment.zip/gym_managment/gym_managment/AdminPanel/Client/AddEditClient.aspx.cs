﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Client
{
    public partial class AddEditClient : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Check valid user
            if (Session["OwnerID"] == null)
                Response.Redirect("~/AdminPanel/Default.aspx");
            #endregion Check valid user

            #region PostBack 
            if (!Page.IsPostBack)
            {
                FillDDLSupplement();
                FillDDLWorkoutType();

                ListItem lidefault = new ListItem();
                lidefault.Text = "Select Package";
                lidefault.Value = "-1";
                ddlPackage.Items.Add(lidefault);

                ListItem li1Month = new ListItem();
                li1Month.Text = "1 Month";
                li1Month.Value = "1";
                ddlPackage.Items.Add(li1Month);

                ListItem li3Month = new ListItem();
                li3Month.Text = "3 Months";
                li3Month.Value = "3";
                ddlPackage.Items.Add(li3Month);

                ListItem li6month = new ListItem();
                li6month.Text = "6 Months";
                li6month.Value = "4";
                ddlPackage.Items.Add(li6month);

                ListItem liyear = new ListItem();
                liyear.Text = "Year";
                liyear.Value = "12";
                ddlPackage.Items.Add(liyear);

                if (Request.QueryString["ClientID"] == null)
                {
                    lblWelcome.Text = "Client Enrollment";
                }
                else
                {
                    lblWelcome.Text = "UPDATE DETAILS | Client ID =" + " " + Request.QueryString["ClientID"].ToString().Trim();
                    FillClientForm(Convert.ToInt32(Request.QueryString["ClientID"].ToString().Trim()));
                }
            }
            #endregion PostBack 
        }
        #endregion Load Event

        #region ddlPackage Index Change Event
        protected void ddlPackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPackage.SelectedIndex > 0)
            {
                if (ddlPackage.SelectedIndex == 1)
                    txtFeeStatus.Text = "1200";

                if (ddlPackage.SelectedIndex == 2)
                    txtFeeStatus.Text = "3000";

                if (ddlPackage.SelectedIndex == 3)
                    txtFeeStatus.Text = "5500";

                if (ddlPackage.SelectedIndex == 2)
                    txtFeeStatus.Text = "10000";
            }
            else
            {
                txtFeeStatus.Text = "Fees Amount";
            }
        }
        #endregion ddlPackage Index Change Event

        #region Save Button
        protected void BtnCSave_Click(object sender, EventArgs e)
        {
            #region  Local variable
            string strMessage = "";
            string strCFileLocationToSave = "";
            string strCPhysicalPath = "";
            #endregion  Local variable

            #region Upload File
            if (fuClientPhoto.HasFiles)
            {
                strCFileLocationToSave += "~/Content/UploadedData/Client/";
                strCPhysicalPath += Server.MapPath(strCFileLocationToSave);
                strCPhysicalPath += fuClientPhoto.FileName;
                if (File.Exists(strCPhysicalPath))
                {
                    File.Delete(strCPhysicalPath);
                }
                fuClientPhoto.SaveAs(strCPhysicalPath);
                strCFileLocationToSave += fuClientPhoto.FileName;
            }
            #endregion Upload File

            #region Server Side Validation
            if (txtClientName.Text.Trim() == "")
                strMessage += "-Enter Client Name<br />";

            if (txtCUserName.Text.Trim() == "")
                strMessage += "-Enter User Name<br />";

            if (txtCPassword.Text.Trim() == "")
                strMessage += "-Enter Password<br />";

            if (txtCMobileNo.Text.Trim() == "")
                strMessage += "-Enter Mobile Number";

            if (ddlPackage.SelectedItem.Value == "-1")
                strMessage += "Select Package";

            if (strMessage != "")
            {
                lblError.Text = strMessage.Trim();
                return;
            }

            #endregion Server Side Validation

            #region Read Data
            ClientENT entClient = new ClientENT();
            if (txtClientName.Text.Trim() != "")
                entClient.ClientName = txtClientName.Text.Trim();

            if (txtCUserName.Text.Trim() != "")
                entClient.UserName = txtCUserName.Text.Trim();

            if (txtCPassword.Text.Trim() != "")
                entClient.Password = txtCPassword.Text.Trim();

            if (txtCMobileNo.Text.Trim() != "")
                entClient.MobileNo = txtCMobileNo.Text.Trim();

            if (txtCAddress.Text.Trim() != "")
                entClient.Address = txtCAddress.Text.Trim();

            if (ddlWorkoutType.SelectedIndex > 0)
                entClient.WorkoutTypeID = Convert.ToInt32(ddlWorkoutType.SelectedItem.Value);

            if (ddlSupplent.SelectedIndex > 0)
                entClient.SupplementID = Convert.ToInt32(ddlSupplent.SelectedItem.Value);

            if (strCFileLocationToSave.Trim() != "")
                entClient.PhotoPath = strCFileLocationToSave.Trim();

            if (txtBirthdate.Text.Trim() != "")
                entClient.Birthdate = Convert.ToDateTime(txtBirthdate.Text.Trim());

            if (ddlPackage.SelectedIndex > 0)
            {
                entClient.ExpiryDate = DateTime.Now.AddMonths(Convert.ToInt32(ddlPackage.SelectedItem.Value));
                if (ddlPackage.SelectedIndex == 1)
                    txtFeeStatus.Text = "1200";

                if (ddlPackage.SelectedIndex == 2)
                    txtFeeStatus.Text = "3000";

                if (ddlPackage.SelectedIndex == 3)
                    txtFeeStatus.Text = "5500";

                if (ddlPackage.SelectedIndex == 2)
                    txtFeeStatus.Text = "10000";
            }

            if (txtFeeStatus.Text.Trim() != "")
                entClient.FeeStatus = txtFeeStatus.Text.Trim();

            entClient.WorkoutTypeID = Convert.ToInt32(ddlWorkoutType.SelectedItem.Value);

            entClient.JoiningDate = DateTime.Now;

            entClient.OwnerID = Convert.ToInt32(1);

            #endregion Read Data

            #region Objects and Methods
            ClientBAL balClient = new ClientBAL();
            if (Request.QueryString["ClientID"] == null)
            {
                if (balClient.InsertByOwnerID(entClient))
                {
                    lblError.Text = "Data Inserted SuccessFully";
                    ClearControls();
                }
                else
                {
                    lblError.Text = balClient.Message;
                }
            }
            else
            {
                entClient.ClientID = Convert.ToInt32(Request.QueryString["ClientID"].ToString().Trim());
                if (balClient.UpdateClient(entClient))
                {
                    Response.Redirect("~/AdminPanel/Client/Client.aspx");
                }
                else
                {
                    lblError.Text = balClient.Message;
                }
            }
            #endregion Objects and Methods
        }
        #endregion Save Button

        #region Clear Controls
        private void ClearControls()
        {
            txtClientName.Text = "";
            txtCUserName.Text = "";
            txtCPassword.Text = "";
            txtCMobileNo.Text = "";
            txtCAddress.Text = "";
            txtBirthdate.Text = "";
            txtFeeStatus.Text = "";
        }
        #endregion Clear Controls

        #region Cancel Button
        protected void BtnCCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminPanel/Client/Client.aspx");
        }
        #endregion Cancel Button

        #region Fill Client Form From ClientID
        private void FillClientForm(SqlInt32 ClientID)
        {
            ClientBAL balClient = new ClientBAL();
            ClientENT entClient = new ClientENT();
            entClient = balClient.SelectByPKOwnerID(Convert.ToInt32(Session["OwnerID"].ToString().Trim()), ClientID);

            if (!entClient.ClientName.IsNull)
                txtClientName.Text = entClient.ClientName.ToString().Trim();

            if (!entClient.UserName.IsNull)
                txtCUserName.Text = entClient.UserName.ToString().Trim();

            if (!entClient.Birthdate.IsNull)
                txtBirthdate.Text = entClient.Birthdate.ToString().Trim();

            if (!entClient.Password.IsNull)
                txtCPassword.Text = entClient.Password.ToString().Trim();

            if (!entClient.Address.IsNull)
                txtCAddress.Text = entClient.Address.ToString().Trim();

            if (!entClient.MobileNo.IsNull)
                txtCMobileNo.Text = entClient.MobileNo.ToString().Trim();

            if (!entClient.FeeStatus.IsNull)
                txtFeeStatus.Text = entClient.FeeStatus.ToString().Trim();

            if (!entClient.WorkoutTypeID.IsNull)
                ddlWorkoutType.SelectedValue = entClient.WorkoutTypeID.ToString().Trim();

            if (!entClient.SupplementID.IsNull)
                ddlSupplent.SelectedValue = entClient.SupplementID.ToString().Trim();
        }
        #endregion Fill Client Form From ClientID

        #region Fill Supplement DropDownList
        private void FillDDLSupplement()
        {
            CommanFillMethods.FillDDLSupplement(ddlSupplent);
        }
        #endregion Fill Supplement DropDownList

        #region Fill WorkoutType DropDownList
        private void FillDDLWorkoutType()
        {
            CommanFillMethods.FillDDLWorkoutType(ddlWorkoutType);
        }
        #endregion Fill WorkoutType DropDownList
    }
}