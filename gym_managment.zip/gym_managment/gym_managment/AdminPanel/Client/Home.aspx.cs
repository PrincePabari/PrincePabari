﻿using BAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gym_managment.AdminPanel.Client
{
    public partial class Home : System.Web.UI.Page
    {
        #region Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ClientID"] == null)
                Response.Redirect("~/Content/AdminPanel/Login/Default.aspx");

            if (Session["ClientName"] != null)
                lblNote.Text = "Welcome" + " " + Session["ClientName"].ToString().Trim();

            if (!Page.IsPostBack)
            {
                FillHome();
            }
        }
        #endregion Load Event

        #region Fill Home
        private void FillHome()
        {
            ClientBAL balClient = new ClientBAL();
            ClientENT entClient = new ClientENT();
            entClient = balClient.SelectByPKOwnerID(Convert.ToInt32(1), Convert.ToInt32(Session["ClientID"].ToString().Trim()));
            if(balClient.Message == null)
            {
                if (!entClient.ClientID.IsNull)
                    lblClientID.Text = entClient.ClientID.ToString().Trim();

                if (!entClient.ClientName.IsNull)
                    lblClientName.Text = entClient.ClientName.ToString().Trim();

                if (!entClient.UserName.IsNull)
                    lblUserName.Text = entClient.UserName.ToString().Trim();

                if (!entClient.MobileNo.IsNull)
                    lblMobileNo.Text = entClient.MobileNo.ToString().Trim();

                if (!entClient.Birthdate.IsNull)
                    lblDate.Text = entClient.Birthdate.ToString().Trim();

                if (!entClient.Address.IsNull)
                {
                    lblCAddress.Text = entClient.Address.ToString().Trim();
                }
                else
                {
                    lblAddress.Visible = false;
                    lblCAddress.Visible = false;
                }
                if (!entClient.FeeStatus.IsNull)
                {
                    lblFees.Text = entClient.FeeStatus.ToString().Trim();
                }
                else
                {
                    lblFees.Visible = false;
                    lblFeeStatus.Visible = false;
                }
                if (!entClient.BMI.IsNull)
                {
                    lblbmiShow.Text = entClient.BMI.ToString().Trim();
                }
                else
                {
                    lblbmiShow.Visible = false;
                    lblBMI.Visible = false;
                }
                if (!entClient.PhotoPath.IsNull)
                {
                    imgClient.ImageUrl = entClient.PhotoPath.ToString().Trim();
                }
                else
                {
                    lblPhoto.Visible = false;
                    imgClient.Visible = false;
                }
                //if (!entClient.ExpiryDate.IsNull)
                //{
                //    if (Convert.ToDateTime(entClient.ExpiryDate.ToString().Trim()) < DateTime.Now)
                //    {
                //        lblSupplementLink.Visible = false;
                //        //lblPages.Visible = false;
                //    }
                //}
                //else
                //{
                //    lblPhoto.Visible = false;
                //    imgClient.Visible = false;
                //}
            }
            else
            {
                lblError.Text = balClient.Message;
            }
        }
        #endregion Fill Home
    }
}