﻿using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ClientDAL : DatabaseConfig
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertByOwnerID(ClientENT entClient)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    objConn.Open();
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_InsertByOwnerID";
                        objCmd.Parameters.Add("@ClientID", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                        objCmd.Parameters.Add("@TrainerID", SqlDbType.Int).Value = entClient.TrainerID;
                        objCmd.Parameters.Add("@OwnerID", SqlDbType.Int).Value = entClient.OwnerID;
                        objCmd.Parameters.Add("@ClientName", SqlDbType.VarChar).Value = entClient.ClientName;
                        objCmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = entClient.UserName;
                        objCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = entClient.Password;
                        objCmd.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = entClient.MobileNo;
                        objCmd.Parameters.Add("@SupplementID", SqlDbType.Int).Value = entClient.SupplementID;
                        objCmd.Parameters.Add("@WorkoutTypeID", SqlDbType.Int).Value = entClient.WorkoutTypeID;
                        objCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = entClient.Address;
                        objCmd.Parameters.Add("@PhotoPath", SqlDbType.VarChar).Value = entClient.PhotoPath;
                        objCmd.Parameters.Add("@FeeStatus", SqlDbType.VarChar).Value = entClient.FeeStatus;
                        objCmd.Parameters.Add("@Membership", SqlDbType.VarChar).Value = entClient.Membership;
                        objCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = entClient.Birthdate;
                        objCmd.Parameters.Add("@JoiningDate", SqlDbType.DateTime).Value = entClient.JoiningDate;
                        objCmd.Parameters.Add("@ExpiryDate", SqlDbType.DateTime).Value = entClient.ExpiryDate;
                        objCmd.Parameters.Add("@BMI", SqlDbType.Float).Value = entClient.BMI;

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        if (objCmd.Parameters["@ClientID"] != null)
                            entClient.ClientID = Convert.ToInt32(objCmd.Parameters["@ClientID"].Value);

                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        #region Update Client
        public Boolean UpdateClient(ClientENT entClient)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_UpdateByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", entClient.OwnerID);
                        objCmd.Parameters.AddWithValue("@TrainerID", entClient.TrainerID);
                        objCmd.Parameters.AddWithValue("@ClientID", entClient.ClientID);
                        objCmd.Parameters.AddWithValue("@UserName", entClient.UserName);
                        objCmd.Parameters.AddWithValue("@Password", entClient.Password);
                        objCmd.Parameters.AddWithValue("@MobileNo", entClient.MobileNo);
                        objCmd.Parameters.AddWithValue("@ClientName", entClient.ClientName);
                        objCmd.Parameters.AddWithValue("@Address", entClient.Address);
                        objCmd.Parameters.AddWithValue("@PhotoPath", entClient.PhotoPath);
                        objCmd.Parameters.AddWithValue("@FeeStatus", entClient.FeeStatus);
                        objCmd.Parameters.AddWithValue("@SupplementID", entClient.SupplementID);
                        objCmd.Parameters.AddWithValue("@WorkoutTypeID", entClient.WorkoutTypeID);
                        objCmd.Parameters.AddWithValue("@Birthdate", entClient.Birthdate);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Update Client

        #region Update BMI
        public Boolean UpdateBMI(ClientENT entClient)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_UpdateBMIByClientID";
                        objCmd.Parameters.AddWithValue("@ClientID", entClient.ClientID);
                        objCmd.Parameters.AddWithValue("@BMI", entClient.BMI);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Update BMI

        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 ClientID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_DeleteByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        objCmd.Parameters.AddWithValue("@ClientID", ClientID);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select All
        public DataTable SelectAll(SqlInt32 OwnerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_SelectAllByOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select All

        #region Select By PK 
        public ClientENT SelectByPKOwnerID(SqlInt32 OwnerID, SqlInt32 ClientID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_SelectByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        objCmd.Parameters.AddWithValue("@ClientID", ClientID);
                        #endregion Prepare Command

                        #region Read Data
                        ClientENT entClient = new ClientENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["ClientID"].Equals(DBNull.Value))
                                    entClient.ClientID = Convert.ToInt32(objSDR["ClientID"].ToString());

                                if (!objSDR["ClientName"].Equals(DBNull.Value))
                                    entClient.ClientName = objSDR["ClientName"].ToString();

                                if (!objSDR["Password"].Equals(DBNull.Value))
                                    entClient.Password = objSDR["Password"].ToString();

                                if (!objSDR["UserName"].Equals(DBNull.Value))
                                    entClient.UserName = objSDR["UserName"].ToString();

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entClient.PhotoPath = objSDR["PhotoPath"].ToString();

                                if (!objSDR["Birthdate"].Equals(DBNull.Value))
                                    entClient.Birthdate = Convert.ToDateTime(objSDR["Birthdate"].ToString());

                                if (!objSDR["FeeStatus"].Equals(DBNull.Value))
                                    entClient.FeeStatus = objSDR["FeeStatus"].ToString();

                                if (!objSDR["Address"].Equals(DBNull.Value))
                                    entClient.Address = objSDR["Address"].ToString();

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entClient.MobileNo = objSDR["MobileNo"].ToString();

                                if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                    entClient.TrainerID = Convert.ToInt32(objSDR["TrainerID"].ToString());

                                if (!objSDR["WorkoutTypeID"].Equals(DBNull.Value))
                                    entClient.WorkoutTypeID = Convert.ToInt32(objSDR["WorkoutTypeID"].ToString());

                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entClient.OwnerID = Convert.ToInt32(objSDR["OwnerID"].ToString());

                                if (!objSDR["BMI"].Equals(DBNull.Value))
                                    entClient.BMI = Convert.ToDouble(objSDR["BMI"].ToString());

                                if (!objSDR["SupplementID"].Equals(DBNull.Value))
                                    entClient.SupplementID = Convert.ToInt32(objSDR["SupplementID"].ToString());

                                if (!objSDR["JoiningDate"].Equals(DBNull.Value))
                                    entClient.JoiningDate = Convert.ToDateTime(objSDR["JoiningDate"].ToString());

                                if (!objSDR["ExpiryDate"].Equals(DBNull.Value))
                                    entClient.ExpiryDate = Convert.ToDateTime(objSDR["ExpiryDate"].ToString());
                            }
                        }
                        return entClient;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select By PK 

        #region Select Client for Login
        public ClientENT SelectClientLogin(SqlString UserName, SqlString Password)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_LoginByUserNamePassword" +
                            "";
                        objCmd.Parameters.AddWithValue("@UserName", UserName);
                        objCmd.Parameters.AddWithValue("@Password", Password);
                        #endregion Prepare Command

                        #region Read Data
                        ClientENT entClient = new ClientENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["ClientID"].Equals(DBNull.Value))
                                    entClient.ClientID = Convert.ToInt32(objSDR["ClientID"].ToString());

                                if (!objSDR["ClientName"].Equals(DBNull.Value))
                                    entClient.ClientName = objSDR["ClientName"].ToString();

                                //if (!objSDR["Password"].Equals(DBNull.Value))
                                //    entClient.Password = objSDR["Password"].ToString();

                                //if (!objSDR["UserName"].Equals(DBNull.Value))
                                //    entClient.UserName = objSDR["UserName"].ToString();

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entClient.PhotoPath = objSDR["PhotoPath"].ToString();

                                if (!objSDR["Birthdate"].Equals(DBNull.Value))
                                    entClient.Birthdate = Convert.ToDateTime(objSDR["Birthdate"].ToString());

                                if (!objSDR["FeeStatus"].Equals(DBNull.Value))
                                    entClient.FeeStatus = objSDR["FeeStatus"].ToString();

                                if (!objSDR["Address"].Equals(DBNull.Value))
                                    entClient.Address = objSDR["Address"].ToString();

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entClient.MobileNo = objSDR["MobileNo"].ToString();

                                //if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                //    entClient.TrainerID = Convert.ToInt32(objSDR["TrainerID"].ToString());

                                if (!objSDR["WorkoutTypeID"].Equals(DBNull.Value))
                                    entClient.WorkoutTypeID = Convert.ToInt32(objSDR["WorkoutTypeID"].ToString());

                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entClient.OwnerID = Convert.ToInt32(objSDR["OwnerID"].ToString());

                                //if (!objSDR["BMI"].Equals(DBNull.Value))
                                //    entClient.BMI = Convert.ToDouble(objSDR["BMI"].ToString());

                                if (!objSDR["SupplementID"].Equals(DBNull.Value))
                                    entClient.SupplementID = Convert.ToInt32(objSDR["SupplementID"].ToString());

                                //if (!objSDR["JoiningDate"].Equals(DBNull.Value))
                                //    entClient.JoiningDate = Convert.ToDateTime(objSDR["JoiningDate"].ToString());

                                //if (!objSDR["ExpiryDate"].Equals(DBNull.Value))
                                //    entClient.ExpiryDate = Convert.ToDateTime(objSDR["ExpiryDate"].ToString());
                            }
                        }
                        return entClient;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select Client for Login

        #region Searching record
        public DataTable SearchClient(SqlString Text)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Client_SearchByName";
                        objCmd.Parameters.AddWithValue("@Text", Text);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Searching record

        #endregion Select Operation

    }
}
