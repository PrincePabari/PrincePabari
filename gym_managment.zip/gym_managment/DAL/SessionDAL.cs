﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENT;
namespace DAL
{
    public class SessionDAL : DatabaseConfig
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertSession(SessionENT entSession)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    if (objConn.State != ConnectionState.Open)
                        objConn.Open();

                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Session_Insert";
                        objCmd.Parameters.Add("@TrainerID", SqlDbType.Int).Value = entSession.TrainerID;
                        objCmd.Parameters.Add("@Session", SqlDbType.VarChar).Value = entSession.Session;
                        objCmd.Parameters.Add("@StartTime", SqlDbType.DateTime).Value = entSession.StartTime;
                        objCmd.Parameters.Add("@EndTime", SqlDbType.DateTime).Value = entSession.EndTime;
                        objCmd.Parameters.Add("@ClientID", SqlDbType.Int).Value = entSession.ClientID;
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Insert Operation

        #region Delete Operation
        public Boolean DeleteSession(SqlInt32 TrainerID, SqlInt32 SessionID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    if (objConn.State != ConnectionState.Open)
                        objConn.Open();

                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Session_DeleteBySessionID";
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        objCmd.Parameters.AddWithValue("@SessionID", SessionID);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;

                    }
                }
                catch(SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return false;
                }
                catch(Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select All
        public DataTable SelectAll(SqlInt32 TrainerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    if (objConn.State != ConnectionState.Open)
                        objConn.Open();

                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Session_SelectAll";
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select All

        #region Select By PK
        public SessionENT SelectByPK(SqlInt32 TrainerID, SqlInt32 SessionID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    if (objConn.State != ConnectionState.Open)
                        objConn.Open();

                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Session_SelectByPK";
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        objCmd.Parameters.AddWithValue("@SessionID", SessionID);
                        #endregion Prepare Command

                        #region Read Data
                        SessionENT entSession = new SessionENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {

                            while(objSDR.Read())
                            {
                                if (!objSDR["SessionID"].Equals(DBNull.Value))
                                    entSession.SessionID = Convert.ToInt32(objSDR["SessionID"]);

                                if (!objSDR["Session"].Equals(DBNull.Value))
                                    entSession.Session = objSDR["Session"].ToString().Trim();

                                if (!objSDR["StartTime"].Equals(DBNull.Value))
                                    entSession.StartTime = Convert.ToDateTime(objSDR["StartTime"]);

                                if (!objSDR["EndTime"].Equals(DBNull.Value))
                                    entSession.EndTime = Convert.ToDateTime(objSDR["EndTime"]);

                                if (!objSDR["ClientID"].Equals(DBNull.Value))
                                    entSession.ClientID = Convert.ToInt32(objSDR["ClientID"]);

                                if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                    entSession.TrainerID = Convert.ToInt32(objSDR["TrainerID"]);

                            }
                            return entSession;
                        }
                        #endregion Read Data

                    }
                }
                catch(SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch(Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select By PK

        #region Select All Previous
        public DataTable SelectAllPrevios(SqlInt32 TrainerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    if (objConn.State != ConnectionState.Open)
                        objConn.Open();

                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Session_SelectAllPreviuos";
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch(SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch(Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select All Previous

        #endregion Select Operation
    }
}
