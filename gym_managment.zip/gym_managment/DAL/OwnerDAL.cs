﻿using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class OwnerDAL : DatabaseConfig
    {
        #region  Local Variables
        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion  Local Variables

        #region Insert Operation
        public Boolean InsertOwner(OwnerENT entOwner)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Owner_InsertByOwnerID";
                        objCmd.Parameters.Add("@OwnerID", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                        objCmd.Parameters.Add("@OwnerName", SqlDbType.VarChar).Value = entOwner.OwnerName;
                        objCmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = entOwner.UserName;
                        objCmd.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = entOwner.MobileNo;
                        objCmd.Parameters.Add("@PhotoPath", SqlDbType.VarChar).Value = entOwner.PhotoPath;

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        if (objCmd.Parameters["@OwnerID"] != null)
                            entOwner.OwnerID = Convert.ToInt32(objCmd.Parameters["@OwnerID"].Value);

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateOwner(OwnerENT entOwner)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Owner_UpdateByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", entOwner.OwnerID);
                        objCmd.Parameters.AddWithValue("@OwnerName", entOwner.OwnerName);
                        objCmd.Parameters.AddWithValue("@UserName", entOwner.UserName);
                        objCmd.Parameters.AddWithValue("@Password", entOwner.Password);
                        objCmd.Parameters.AddWithValue("@MobileNo", entOwner.MobileNo);
                        objCmd.Parameters.AddWithValue("@PhotoPath", entOwner.PhotoPath);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPK(SqlInt32 OwnerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Owner_DeleteByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select By PK
        public OwnerENT SelectByPKOwnerID(SqlInt32 OwnerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Owner_SelectByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        #endregion Prepare Command

                        #region Read Data and Set Controls
                        OwnerENT entowner = new OwnerENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entowner.OwnerID = Convert.ToInt32(objSDR["OwnerID"]);

                                if (!objSDR["OwnerName"].Equals(DBNull.Value))
                                    entowner.OwnerName = Convert.ToString(objSDR["OwnerName"]);

                                if (!objSDR["UserName"].Equals(DBNull.Value))
                                    entowner.UserName = Convert.ToString(objSDR["UserName"]);

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entowner.MobileNo = Convert.ToString(objSDR["MobileNo"]);

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entowner.PhotoPath = Convert.ToString(objSDR["PhotoPath"]);
                            }
                            return entowner;
                        }
                        #endregion Read Data and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Select By PK

        #region select for Login
        public OwnerENT SelectForLogin(SqlString UserName, SqlString Password)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Owner_LoginByUserNamePassword";
                        objCmd.Parameters.AddWithValue("@UserName", UserName);
                        objCmd.Parameters.AddWithValue("@Password", Password);
                        #endregion Prepare Command

                        #region Read Data and Set Controls
                        OwnerENT entowner = new OwnerENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entowner.OwnerID = Convert.ToInt32(objSDR["OwnerID"]);

                                if (!objSDR["OwnerName"].Equals(DBNull.Value))
                                    entowner.OwnerName = Convert.ToString(objSDR["OwnerName"]);

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entowner.MobileNo = Convert.ToString(objSDR["MobileNo"]);

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entowner.PhotoPath = Convert.ToString(objSDR["PhotoPath"]);

                            }
                            return entowner;
                        }
                        #endregion Read Data and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message;
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message;
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion select for Login

        #endregion Select Operation
    }
}
