﻿using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class TrainerDAL : DatabaseConfig
    {
        #region Local Variables
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation
        public Boolean InsertByOwnerID(TrainerENT entTrainer)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                try
                {
                    objConn.Open();
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_InsertByOwnerID";
                        objCmd.Parameters.Add("@TrainerID", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                        objCmd.Parameters.Add("@OwnerID", SqlDbType.Int).Value = entTrainer.OwnerID;
                        objCmd.Parameters.Add("@TrainerName", SqlDbType.VarChar).Value = entTrainer.TrainerName;
                        objCmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = entTrainer.UserName;
                        objCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = entTrainer.Password;
                        objCmd.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = entTrainer.MobileNo;
                        objCmd.Parameters.Add("@Experience", SqlDbType.Int).Value = entTrainer.ExperienceYears;
                        objCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = entTrainer.Address;
                        objCmd.Parameters.Add("@PhotoPath", SqlDbType.VarChar).Value = entTrainer.PhotoPath;
                        objCmd.Parameters.Add("@SpecialistOf", SqlDbType.VarChar).Value = entTrainer.SpecialistOf;
                        objCmd.Parameters.Add("@Salary", SqlDbType.VarChar).Value = entTrainer.Salary;

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        if (objCmd.Parameters["@TrainerID"] != null)
                            entTrainer.TrainerID = Convert.ToInt32(objCmd.Parameters["@TrainerID"].Value);

                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateOwner(TrainerENT entTrainer)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_UpdateByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", entTrainer.OwnerID);
                        objCmd.Parameters.AddWithValue("@TrainerID", entTrainer.TrainerID);
                        objCmd.Parameters.AddWithValue("@TrainerName", entTrainer.TrainerName);
                        objCmd.Parameters.AddWithValue("@UserName", entTrainer.UserName);
                        objCmd.Parameters.AddWithValue("@Password", entTrainer.Password);
                        objCmd.Parameters.AddWithValue("@MobileNo", entTrainer.MobileNo);
                        objCmd.Parameters.AddWithValue("@Experience", entTrainer.ExperienceYears);
                        objCmd.Parameters.AddWithValue("@Address", entTrainer.Address);
                        objCmd.Parameters.AddWithValue("@PhotoPath", entTrainer.PhotoPath);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 TrainerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_DeleteByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select ALL
        public DataTable SelectAll(SqlInt32 OwnerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_SelectAllByOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select ALL

        #region Select By PK
        public TrainerENT SelectByPKOwnerID(SqlInt32 TrainerID, SqlInt32 OwnerID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_SelectByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        #endregion Prepare Command

                        #region Read Data
                        TrainerENT entTrainer = new TrainerENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                    entTrainer.TrainerID = Convert.ToInt32(objSDR["TrainerID"].ToString().Trim());

                                if (!objSDR["TrainerName"].Equals(DBNull.Value))
                                    entTrainer.TrainerName = objSDR["TrainerName"].ToString().Trim();

                                if (!objSDR["Password"].Equals(DBNull.Value))
                                    entTrainer.Password = objSDR["Password"].ToString().Trim();

                                if (!objSDR["UserName"].Equals(DBNull.Value))
                                    entTrainer.UserName = objSDR["UserName"].ToString().Trim();

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entTrainer.PhotoPath = objSDR["PhotoPath"].ToString().Trim();

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entTrainer.MobileNo = objSDR["MobileNo"].ToString().Trim();

                                if (!objSDR["ExperienceYears"].Equals(DBNull.Value))
                                    entTrainer.ExperienceYears = Convert.ToInt32(objSDR["ExperienceYears"].ToString().Trim());

                                if (!objSDR["Address"].Equals(DBNull.Value))
                                    entTrainer.Address = objSDR["Address"].ToString().Trim();

                                if (!objSDR["Salary"].Equals(DBNull.Value))
                                    entTrainer.Salary = objSDR["Salary"].ToString().Trim();

                                if (!objSDR["SpecialistOf"].Equals(DBNull.Value))
                                    entTrainer.SpecialistOf = objSDR["SpecialistOf"].ToString().Trim();
                            }
                            return entTrainer;
                        }
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select By PK

        #region Select for Login
        public TrainerENT SelectForLogin(SqlString UserName, SqlString Password)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_LoginByUserNamePassword";
                        objCmd.Parameters.AddWithValue("@UserName", UserName);
                        objCmd.Parameters.AddWithValue("@Password", Password);
                        #endregion Prepare Command

                        #region Read Data
                        TrainerENT entTrainer = new TrainerENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                    entTrainer.TrainerID = Convert.ToInt32(objSDR["TrainerID"].ToString().Trim());

                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entTrainer.OwnerID = Convert.ToInt32(objSDR["OwnerID"].ToString().Trim());

                                if (!objSDR["TrainerName"].Equals(DBNull.Value))
                                    entTrainer.TrainerName = objSDR["TrainerName"].ToString().Trim();

                                //if (!objSDR["Password"].Equals(DBNull.Value))
                                //    entTrainer.Password = objSDR["Password"].ToString().Trim();

                                //if (!objSDR["UserName"].Equals(DBNull.Value))
                                //    entTrainer.UserName = objSDR["UserName"].ToString().Trim();

                                if (!objSDR["PhotoPath"].Equals(DBNull.Value))
                                    entTrainer.PhotoPath = objSDR["PhotoPath"].ToString().Trim();

                                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                                    entTrainer.MobileNo = objSDR["MobileNo"].ToString().Trim();

                                if (!objSDR["ExperienceYears"].Equals(DBNull.Value))
                                    entTrainer.ExperienceYears = Convert.ToInt32(objSDR["ExperienceYears"].ToString().Trim());

                                if (!objSDR["Address"].Equals(DBNull.Value))
                                    entTrainer.Address = objSDR["Address"].ToString().Trim();

                                if (!objSDR["Salary"].Equals(DBNull.Value))
                                    entTrainer.Salary = objSDR["Salary"].ToString().Trim();

                                if (!objSDR["SpecialistOf"].Equals(DBNull.Value))
                                    entTrainer.SpecialistOf = objSDR["SpecialistOf"].ToString().Trim();
                            }
                            return entTrainer;
                        }
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message;
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message;
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select for Login

        #region Searching Record
        public DataTable SearchTrainer(SqlString Text)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Trainer_SearchByName";
                        objCmd.Parameters.AddWithValue("@Text", Text);
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Searching Record

        #endregion Select Operation

    }
}
