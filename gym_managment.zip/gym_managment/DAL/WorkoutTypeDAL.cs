﻿using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class WorkoutTypeDAL : DatabaseConfig
    {
        #region Local Variables
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation
        public Boolean InsertWorkout(WorkoutTypeENT entWorkoutType)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_WorkoutType_InsertByOwnerID";
                        objCmd.Parameters.Add("@WorkoutTypeID", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                        objCmd.Parameters.Add("@OwnerID", SqlDbType.Int).Value = entWorkoutType.OwnerID;
                        objCmd.Parameters.Add("@WorkoutType", SqlDbType.VarChar).Value = entWorkoutType.WorkoutType;
                        objCmd.Parameters.Add("@TrainerID", SqlDbType.Int).Value = entWorkoutType.TrainerID;
                        objCmd.Parameters.Add("@ClientID", SqlDbType.Int).Value = entWorkoutType.ClientID;

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        if (objCmd.Parameters["WorkoutTypeID"] != null)
                            entWorkoutType.WorkoutTypeID = (SqlInt32)objCmd.Parameters["WorkoutTypeID"].Value;

                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateWorkout(WorkoutTypeENT entWorkoutType)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_WorkoutType_UpdateByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", entWorkoutType.OwnerID);
                        objCmd.Parameters.AddWithValue("@WorkoutTypeID", entWorkoutType.WorkoutTypeID);
                        objCmd.Parameters.AddWithValue("@WorkoutType", entWorkoutType.WorkoutType);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 WorkoutTypeID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_WorkoutType_DeleteByPKOwnerID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        objCmd.Parameters.AddWithValue("@WorkoutTypeID", WorkoutTypeID);
                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return false;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return false;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select By PK
        public WorkoutTypeENT SelectByPK(SqlInt32 OwnerID, SqlInt32 WorkoutTypeID, SqlInt32 TrainerID, SqlInt32 ClientID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_WorkoutType_SelectAllByPKUserID";
                        objCmd.Parameters.AddWithValue("@OwnerID", OwnerID);
                        objCmd.Parameters.AddWithValue("@WorkoutTypeID", WorkoutTypeID);
                        objCmd.Parameters.AddWithValue("@TrainerID", TrainerID);
                        objCmd.Parameters.AddWithValue("@ClientID", ClientID);
                        #endregion Prepare Command

                        #region Read Data
                        WorkoutTypeENT entWorkoutType = new WorkoutTypeENT();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["WorkoutTypeID"].Equals(DBNull.Value))
                                    entWorkoutType.WorkoutTypeID = Convert.ToInt32(objSDR["WorkoutTypeID"].ToString());

                                if (!objSDR["WorkoutType"].Equals(DBNull.Value))
                                    entWorkoutType.WorkoutType = objSDR["WorkoutType"].ToString();

                                if (!objSDR["OwnerID"].Equals(DBNull.Value))
                                    entWorkoutType.OwnerID = Convert.ToInt32(objSDR["OwnerID"].ToString());

                                if (!objSDR["TrainerID"].Equals(DBNull.Value))
                                    entWorkoutType.TrainerID = Convert.ToInt32(objSDR["TrainerID"].ToString());

                                if (!objSDR["ClientID"].Equals(DBNull.Value))
                                    entWorkoutType.ClientID = Convert.ToInt32(objSDR["ClientID"].ToString());
                            }
                        }
                        return entWorkoutType;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select By PK

        #region Select For Dropdownlist
        public DataTable SelectForDDL()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                try
                {
                    using (SqlCommand objCmd = objConn.CreateCommand())
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_WorkoutType_SelectDropDownList";
                        #endregion Prepare Command

                        #region Read Data
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion Read Data
                    }
                }
                catch (SqlException sqlex)
                {
                    Message = sqlex.InnerException.Message.ToString();
                    return null;
                }
                catch (Exception ex)
                {
                    Message = ex.InnerException.Message.ToString();
                    return null;
                }
                finally
                {
                    if (objConn.State == ConnectionState.Open)
                        objConn.Close();
                }
            }
        }
        #endregion Select For Dropdownlist

        #endregion Select Operation

    }
}
