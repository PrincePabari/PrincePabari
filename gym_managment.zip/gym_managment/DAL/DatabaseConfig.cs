﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DAL
{
    public class DatabaseConfig
    {
        public static string ConnectionString = "Data Source=LAPTOP-VP09T4DH; Initial Catalog=HustlersGYM; Integrated Security=True";
    }
}
