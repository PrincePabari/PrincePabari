﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class ContactBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean Insert(ContactENT entContact)
        {
            ContactDAL dalContact = new ContactDAL();
            if (dalContact.Insert(entContact))
            {
                return true;
            }
            else
            {
                Message = dalContact.Message;
                return false;
            }
        }
        #endregion Insert Operation

        #region Delete Operation
        public Boolean DeleteByPK(SqlInt32 OwnerID, SqlInt32 ContactID)
        {
            ContactDAL dalContact = new ContactDAL();
            if (dalContact.DeleteByPK(OwnerID, ContactID))
            {
                return true;
            }
            else
            {
                Message = dalContact.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region SelectAll
        public DataTable SelectAll(SqlInt32 OwnerID)
        {
            ContactDAL dalContact = new ContactDAL();
            return dalContact.SelectAll(OwnerID);
        }
        #endregion SelectAll

        #region Select By PK
        public ContactENT SelectByPKOwnerID(SqlInt32 OwnerID, SqlInt32 ContactID)
        {
            ContactDAL dalContact = new ContactDAL();
            return dalContact.SelectByPKOwnerID(OwnerID, ContactID);
        }
        #endregion Select By PK

        #region Searching selection
        public DataTable SearchContact(SqlString Text)
        {
            ContactDAL dalContact = new ContactDAL();
            return dalContact.SearchContact(Text);
        }
        #endregion Searching selection

        #endregion Select Operation
    }
}
