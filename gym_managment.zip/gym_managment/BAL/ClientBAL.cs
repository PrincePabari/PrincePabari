﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class ClientBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertByOwnerID(ClientENT entClient)
        {
            ClientDAL dalClient = new ClientDAL();
            if (dalClient.InsertByOwnerID(entClient))
            {
                return true;
            }
            else
            {
                Message = dalClient.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        #region Client Update
        public Boolean UpdateClient(ClientENT entClient)
        {
            ClientDAL dalClient = new ClientDAL();
            if (dalClient.UpdateClient(entClient))
            {
                return true;
            }
            else
            {
                Message = dalClient.Message;
                return true;
            }
        }
        #endregion Client Update

        #region BMI Update
        public Boolean UpdateBMI(ClientENT entClient)
        {
            ClientDAL dalClient = new ClientDAL();
            if (dalClient.UpdateBMI(entClient))
            {
                return true;
            }
            else
            {
                Message = dalClient.Message;
                return true;
            }
        }
        #endregion BMI Update

        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 ClientID)
        {
            ClientDAL dalClient = new ClientDAL();
            if (dalClient.DeleteByPKOwnerID(OwnerID, ClientID))
            {
                return true;
            }
            else
            {
                Message = dalClient.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select ALL
        public DataTable SelectAll(SqlInt32 OwnerID)
        {
            ClientDAL dalClient = new ClientDAL();
            return dalClient.SelectAll(OwnerID);
        }
        #endregion Select All

        #region Select By PK
        public ClientENT SelectByPKOwnerID(SqlInt32 OwnerID, SqlInt32 ClientID)
        {
            ClientDAL dalClient = new ClientDAL();
            return dalClient.SelectByPKOwnerID(OwnerID, ClientID);
        }
        #endregion Select By PK

        #region Select for Login
        public ClientENT SelectClientLogin(SqlString UserName, SqlString Password)
        {
            ClientDAL dalClient = new ClientDAL();
            return dalClient.SelectClientLogin(UserName, Password);
        }
        #endregion Select for Login

        #region Searching record
        public DataTable SearchClient(SqlString Text)
        {
            ClientDAL dalClient = new ClientDAL();
            return dalClient.SearchClient(Text);
        }
        #endregion Searching record

        #endregion Select Operation
    }
}
