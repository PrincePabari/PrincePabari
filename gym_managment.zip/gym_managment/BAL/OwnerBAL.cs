﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using ENT;
using System.Data.SqlTypes;

namespace BAL
{
    public class OwnerBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertOwner(OwnerENT entOwner)
        {
            OwnerDAL dalOwner = new OwnerDAL();
            if (dalOwner.InsertOwner(entOwner))
            {
                return true;
            }
            else
            {
                Message = dalOwner.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateOwner(OwnerENT entOwner)
        {
            OwnerDAL dalOwner = new OwnerDAL();
            if (dalOwner.InsertOwner(entOwner))
            {
                return true;
            }
            else
            {
                Message = dalOwner.Message;
                return true;
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPK(SqlInt32 OwnerID)
        {
            OwnerDAL dalOwner = new OwnerDAL();
            if (dalOwner.DeleteByPK(OwnerID))
            {
                return true;
            }
            else
            {
                Message = dalOwner.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select By PK
        public OwnerENT SelectByPKOwnerID(SqlInt32 OwnerID)
        {
            OwnerDAL dalowner = new OwnerDAL();
            return dalowner.SelectByPKOwnerID(OwnerID);
        }
        #endregion Select By PK

        #region select for Login
        public OwnerENT SelectForLogin(SqlString UserName, SqlString Password)
        {
            OwnerDAL dalowner = new OwnerDAL();
            return dalowner.SelectForLogin(UserName, Password);
        }
        #endregion select for Login

        #endregion Select Operation
    }
}
