﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace BAL
{
    public class CommanFillMethods
    {
        public static void FillDDLWorkoutType(DropDownList ddl)
        {
            WorkoutTypeBAL balworkoutType = new WorkoutTypeBAL();
            ddl.DataSource = balworkoutType.SelectForDDL();
            ddl.DataValueField = "WorkoutTypeID";
            ddl.DataTextField = "WorkoutType";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Workout Type", "-1"));
        }

        public static void FillDDLSupplement(DropDownList ddl)
        {
            SupplementBAL balSupplement = new SupplementBAL();
            ddl.DataSource = balSupplement.SelectForDDL();
            ddl.DataValueField = "SupplementID";
            ddl.DataTextField = "SupplementName";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Supplement", "-1"));
        }
    }
}
