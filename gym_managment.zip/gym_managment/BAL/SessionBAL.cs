﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class SessionBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertSession(SessionENT entSession)
        {
            SessionDAL dalSession = new SessionDAL();
            if (dalSession.InsertSession(entSession))
            {
                return true;
            }
            else
            {
                _Message = dalSession.Message;
                return false;
            }
        }
        #endregion Insert Operation

        #region Delete Operation
        public Boolean DeleteSession(SqlInt32 TrainerID, SqlInt32 SessionID)
        {
            SessionDAL dalSession = new SessionDAL();
            if (dalSession.DeleteSession(TrainerID, SessionID))
            {
                return true;
            }
            else
            {
                _Message = dalSession.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select All
        public DataTable SelectAll(SqlInt32 TrainerID)
        {
            SessionDAL dalSession = new SessionDAL();
            return dalSession.SelectAll(TrainerID);
        }
        #endregion Select All

        #region Select By PK
        public SessionENT SelectByPK(SqlInt32 TrainerID, SqlInt32 SessionID)
        {
            SessionDAL dalSession = new SessionDAL();
            return dalSession.SelectByPK(TrainerID, SessionID);
        }
        #endregion Select By PK

        #region Select All Previous 
        public DataTable SelectAllPrevios(SqlInt32 TrainerID)
        {
            SessionDAL dalSession = new SessionDAL();
            return dalSession.SelectAllPrevios(TrainerID);
        }
        #endregion Select All Previous 

        #endregion Select Operation
    }
}
