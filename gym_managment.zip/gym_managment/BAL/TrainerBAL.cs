﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class TrainerBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertByOwnerID(TrainerENT entTrainer)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            if (dalTrainer.InsertByOwnerID(entTrainer))
            {
                return true;
            }
            else
            {
                Message = dalTrainer.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateOwner(TrainerENT entTrainer)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            if (dalTrainer.UpdateOwner(entTrainer))
            {
                return true;
            }
            else
            {
                Message = dalTrainer.Message;
                return true;
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 TrainerID)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            if (dalTrainer.DeleteByPKOwnerID(OwnerID, TrainerID))
            {
                return true;
            }
            else
            {
                Message = dalTrainer.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select ALL
        public DataTable SelectAll(SqlInt32 OwnerID)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            return dalTrainer.SelectAll(OwnerID);
        }
        #endregion Select All

        #region Select By PK
        public TrainerENT SelectByPKOwnerID(SqlInt32 TrainerID, SqlInt32 OwnerID)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            return dalTrainer.SelectByPKOwnerID(TrainerID, OwnerID);
        }
        #endregion Select By PK

        #region Select for Login
        public TrainerENT SelectForLogin(SqlString UserName, SqlString Password)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            return dalTrainer.SelectForLogin(UserName, Password);
        }
        #endregion Select for Login

        #region Searching Record
        public DataTable SearchTrainer(SqlString Text)
        {
            TrainerDAL dalTrainer = new TrainerDAL();
            return dalTrainer.SearchTrainer(Text);
        }
        #endregion Searching Record

        #endregion Select Operation
    }
}
