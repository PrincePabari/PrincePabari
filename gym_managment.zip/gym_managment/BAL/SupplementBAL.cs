﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class SupplementBAL
    {
        #region Local Variable
        protected string _Message;
        public string SupplementID;
        public string SupplementName;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertSupplement(SupplementENT entSupplement)
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            if (dalSupplement.InsertSupplement(entSupplement))
            {
                return true;
            }
            else
            {
                Message = dalSupplement.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateSupplement(SupplementENT entSupplement)
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            if (dalSupplement.UpdateSupplement(entSupplement))
            {
                return true;
            }
            else
            {
                Message = dalSupplement.Message;
                return true;
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 SupplementID)
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            if (dalSupplement.DeleteByPKOwnerID(OwnerID, SupplementID))
            {
                return true;
            }
            else
            {
                Message = dalSupplement.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select ALL
        public DataTable SelectAll()
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            return dalSupplement.SelectAll();
        }
        #endregion Select All

        #region Select By PK
        public SupplementENT SelectByPKOwnerID(SqlInt32 OwnerID, SqlInt32 SupplementID)
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            return dalSupplement.SelectByPKOwnerID(OwnerID, SupplementID);
        }
        #endregion Select By PK

        #region Select For DropDownList
        public DataTable SelectForDDL()
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            return dalSupplement.SelectForDDL();
        }
        #endregion Select for DropDownList

        #region Searching record
        public DataTable SearchSupp(SqlString Text)
        {
            SupplementDAL dalSupplement = new SupplementDAL();
            return dalSupplement.SearchSupp(Text);
        }
        #endregion Searching record

        #endregion Select Operation
    }
}
