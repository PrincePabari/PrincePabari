﻿using DAL;
using ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class WorkoutTypeBAL
    {
        #region Local Variable
        protected string _Message;

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Operation
        public Boolean InsertWorkout(WorkoutTypeENT entWorkoutType)
        {
            WorkoutTypeDAL dalWorkoutType = new WorkoutTypeDAL();
            if (dalWorkoutType.InsertWorkout(entWorkoutType))
            {
                return true;
            }
            else
            {
                Message = dalWorkoutType.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation
        public Boolean UpdateWorkout(WorkoutTypeENT entWorkoutType)
        {
            WorkoutTypeDAL dalWorkoutType = new WorkoutTypeDAL();
            if (dalWorkoutType.UpdateWorkout(entWorkoutType))
            {
                return true;
            }
            else
            {
                Message = dalWorkoutType.Message;
                return true;
            }
        }
        #endregion Update Operation

        #region Delete Operation
        public Boolean DeleteByPKOwnerID(SqlInt32 OwnerID, SqlInt32 WorkoutTypeID)
        {
            WorkoutTypeDAL dalWorkoutType = new WorkoutTypeDAL();
            if (dalWorkoutType.DeleteByPKOwnerID(OwnerID, WorkoutTypeID))
            {
                return true;
            }
            else
            {
                Message = dalWorkoutType.Message;
                return false;
            }
        }
        #endregion Delete Operation

        #region Select Operation

        #region Select By PK
        public WorkoutTypeENT SelectByPK(SqlInt32 OwnerID, SqlInt32 WorkoutTypeID, SqlInt32 TrainerID, SqlInt32 ClientID)
        {
            WorkoutTypeDAL dalWorkoutType = new WorkoutTypeDAL();
            return dalWorkoutType.SelectByPK(OwnerID, WorkoutTypeID, TrainerID, ClientID);
        }
        #endregion Select By PK

        #region Select For DropDownList
        public DataTable SelectForDDL()
        {
            WorkoutTypeDAL dalWorkoutType = new WorkoutTypeDAL();
            return dalWorkoutType.SelectForDDL();
        }
        #endregion Select for DropDownList

        #endregion Select Operation
    }
}
