﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class ClientENT
    {
        #region ClientID
        protected SqlInt32 _ClientID;
        public SqlInt32 ClientID
        {
            get
            {
                return _ClientID;
            }
            set
            {
                _ClientID = value;
            }
        }
        #endregion ClientID

        #region ClientName
        protected SqlString _ClientName;
        public SqlString ClientName
        {
            get
            {
                return _ClientName;
            }
            set
            {
                _ClientName = value;
            }
        }
        #endregion ClientName

        #region UserName
        protected SqlString _UserName;
        public SqlString UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }
        #endregion UserName

        #region Password
        protected SqlString _Password;
        public SqlString Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }
        #endregion Password

        #region Birthdate
        protected SqlDateTime _Birthdate;
        public SqlDateTime Birthdate
        {
            get
            {
                return _Birthdate;
            }
            set
            {
                _Birthdate = value;
            }
        }
        #endregion Birthdate

        #region MobileNo
        protected SqlString _MobileNo;
        public SqlString MobileNo
        {
            get
            {
                return _MobileNo;
            }
            set
            {
                _MobileNo = value;
            }
        }
        #endregion MobileNo

        #region Address
        protected SqlString _Address;
        public SqlString Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }
        #endregion Address

        #region FeeStatus
        protected SqlString _FeeStatus;
        public SqlString FeeStatus
        {
            get
            {
                return _FeeStatus;
            }
            set
            {
                _FeeStatus = value;
            }
        }
        #endregion FeeStatus

        #region OwnerID
        protected SqlInt32 _OwnerID;
        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID

        #region TrainerID
        protected SqlInt32 _TrainerID;
        public SqlInt32 TrainerID
        {
            get
            {
                return _TrainerID;
            }
            set
            {
                _TrainerID = value;
            }
        }
        #endregion TrainerID

        #region SupplementID
        protected SqlInt32 _SupplementID;
        public SqlInt32 SupplementID
        {
            get
            {
                return _SupplementID;
            }
            set
            {
                _SupplementID = value;
            }
        }
        #endregion SupplementID

        #region WorkoutTypeID
        protected SqlInt32 _WorkoutTypeID;
        public SqlInt32 WorkoutTypeID
        {
            get
            {
                return _WorkoutTypeID;
            }
            set
            {
                _WorkoutTypeID = value;
            }
        }
        #endregion WorkoutTypeID

        #region PhotoPath
        protected SqlString _PhotoPath;
        public SqlString PhotoPath
        {
            get
            {
                return _PhotoPath;
            }
            set
            {
                _PhotoPath = value;
            }
        }
        #endregion PhotoPath

        #region Membership
        protected SqlString _Membership;
        public SqlString Membership
        {
            get
            {
                return _Membership;
            }
            set
            {
                _Membership = value;
            }
        }
        #endregion Membership

        #region JoiningDate
        protected SqlDateTime _JoiningDate;
        public SqlDateTime JoiningDate
        {
            get
            {
                return _JoiningDate;
            }
            set
            {
                _JoiningDate = value;
            }
        }
        #endregion JoiningDate

        #region ExpiryDate
        protected SqlDateTime _ExpiryDate;
        public SqlDateTime ExpiryDate
        {
            get
            {
                return _ExpiryDate;
            }
            set
            {
                _ExpiryDate = value;
            }
        }
        #endregion ExpiryDate

        #region BMI
        protected SqlDouble _BMI;
        public SqlDouble BMI
        {
            get
            {
                return _BMI;
            }
            set
            {
                _BMI = value;
            }
        }
        #endregion BMI
    }
}
