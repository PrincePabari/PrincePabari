﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Threading.Tasks;

namespace ENT
{
    public class OwnerENT
    {
        #region OwnerID
        protected SqlInt32 _OwnerID;

        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID

        #region OwnerName
        protected SqlString _OwnerName;
        public SqlString OwnerName
        {
            get
            {
                return _OwnerName;
            }
            set
            {
                _OwnerName = value;
            }
        }
        #endregion OwnerName

        #region UserName
        protected SqlString _UserName;
        public SqlString UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }
        #endregion UserName

        #region Password
        protected SqlString _Password;
        public SqlString Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }
        #endregion Password

        #region MobileNo
        protected SqlString _MobileNo;
        public SqlString MobileNo
        {
            get
            {
                return _MobileNo;
            }
            set
            {
                _MobileNo = value;
            }
        }
        #endregion MobileNo

        #region PhotoPath
        protected SqlString _PhotoPath;
        public SqlString PhotoPath
        {
            get
            {
                return _PhotoPath;
            }
            set
            {
                _PhotoPath = value;
            }
        }
        #endregion PhotoPath
    }
}
