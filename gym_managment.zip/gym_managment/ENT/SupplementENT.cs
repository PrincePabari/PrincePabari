﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class SupplementENT
    {
        #region SupplementID
        protected SqlInt32 _SupplementID;
        public SqlInt32 SupplementID
        {
            get
            {
                return _SupplementID;
            }
            set
            {
                _SupplementID = value;
            }
        }
        #endregion SupplementID

        #region SupplementName
        protected SqlString _SupplementName;
        public SqlString SupplementName
        {
            get
            {
                return _SupplementName;
            }
            set
            {
                _SupplementName = value;
            }
        }
        #endregion SupplementName

        #region Price
        protected SqlString _Price;
        public SqlString Price
        {
            get
            {
                return _Price;
            }
            set
            {
                _Price = value;
            }
        }
        #endregion Price

        #region PhotoPath
        protected SqlString _PhotoPath;
        public SqlString PhotoPath
        {
            get
            {
                return _PhotoPath;
            }
            set
            {
                _PhotoPath = value;
            }
        }
        #endregion PhotoPath

        #region OwnerID
        protected SqlInt32 _OwnerID;
        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID

        #region ClientID
        protected SqlInt32 _ClientID;
        public SqlInt32 ClientID
        {
            get
            {
                return _ClientID;
            }
            set
            {
                _ClientID = value;
            }
        }
        #endregion ClientID
    }
}
