﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class SessionENT
    {
        #region SessionID
        protected SqlInt32 _SessionID;

        public SqlInt32 SessionID
        {
            get
            {
                return _SessionID;
            }
            set
            {
                _SessionID = value;
            }
        }
        #endregion SessionID

        #region Session
        protected SqlString _Session;

        public SqlString Session
        {
            get
            {
                return _Session;
            }
            set
            {
                _Session = value;
            }
        }
        #endregion Session

        #region StartTime
        protected SqlDateTime _StartTime;

        public SqlDateTime StartTime
        {
            get
            {
                return _StartTime;
            }
            set
            {
                _StartTime = value;
            }
        }
        #endregion StartTime

        #region EndTime
        protected SqlDateTime _EndTime;

        public SqlDateTime EndTime
        {
            get
            {
                return _EndTime;
            }
            set
            {
                _EndTime = value;
            }
        }
        #endregion EndTime

        #region TrainerID
        protected SqlInt32 _TrainerID;

        public SqlInt32 TrainerID
        {
            get
            {
                return _TrainerID;
            }
            set
            {
                _TrainerID = value;
            }
        }
        #endregion TrainerID

        #region ClientID
        protected SqlInt32 _ClientID;

        public SqlInt32 ClientID
        {
            get
            {
                return _ClientID;
            }
            set
            {
                _ClientID = value;
            }
        }
        #endregion ClientID
    }
}
