﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class ContactENT
    {
        #region ContactID
        protected SqlInt32 _ContactID;

        public SqlInt32 ContactID
        {
            get
            {
                return _ContactID;
            }
            set
            {
                _ContactID = value;
            }
        }
        #endregion ContactID

        #region Name
        protected SqlString _Name;

        public SqlString Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }
        #endregion Name

        #region Email
        protected SqlString _Email;

        public SqlString Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }
        #endregion Email

        #region Comment
        protected SqlString _Comment;

        public SqlString Comment
        {
            get
            {
                return _Comment;
            }
            set
            {
                _Comment = value;
            }
        }
        #endregion Comment

        #region TrainerID
        protected SqlInt32 _TrainerID;

        public SqlInt32 TrainerID
        {
            get
            {
                return _TrainerID;
            }
            set
            {
                _TrainerID = value;
            }
        }
        #endregion TrainerID

        #region ClientID
        protected SqlInt32 _ClientID;

        public SqlInt32 ClientID
        {
            get
            {
                return _ClientID;
            }
            set
            {
                _ClientID = value;
            }
        }
        #endregion ClientID

        #region OwnerID
        protected SqlInt32 _OwnerID;

        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID
    }
}
