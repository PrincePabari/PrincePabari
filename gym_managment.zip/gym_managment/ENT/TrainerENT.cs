﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class TrainerENT
    {
        #region TrainerID
        protected SqlInt32 _TrainerID;
        public SqlInt32 TrainerID
        {
            get
            {
                return _TrainerID;
            }
            set
            {
                _TrainerID = value;
            }
        }
        #endregion TrainerID

        #region TrainerName
        protected SqlString _TrainerName;
        public SqlString TrainerName
        {
            get
            {
                return _TrainerName;
            }
            set
            {
                _TrainerName = value;
            }
        }
        #endregion TrainerName

        #region UserName
        protected SqlString _UserName;
        public SqlString UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }
        #endregion UserName

        #region Password
        protected SqlString _Password;
        public SqlString Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }
        #endregion Password

        #region MobileNo
        protected SqlString _MobileNo;
        public SqlString MobileNo
        {
            get
            {
                return _MobileNo;
            }
            set
            {
                _MobileNo = value;
            }
        }
        #endregion MobileNo

        #region Address
        protected SqlString _Address;
        public SqlString Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }
        #endregion Address

        #region PhotoPath
        protected SqlString _PhotoPath;
        public SqlString PhotoPath
        {
            get
            {
                return _PhotoPath;
            }
            set
            {
                _PhotoPath = value;
            }
        }
        #endregion PhotoPath

        #region ExperienceYears
        protected SqlInt32 _ExperienceYears;
        public SqlInt32 ExperienceYears
        {
            get
            {
                return _ExperienceYears;
            }
            set
            {
                _ExperienceYears = value;
            }
        }
        #endregion ExperienceYears

        #region Salary
        protected SqlString _Salary;
        public SqlString Salary
        {
            get
            {
                return _Salary;
            }
            set
            {
                _Salary = value;
            }
        }
        #endregion Salary

        #region SpecialistOf
        protected SqlString _SpecialistOf;
        public SqlString SpecialistOf
        {
            get
            {
                return _SpecialistOf;
            }
            set
            {
                _SpecialistOf = value;
            }
        }
        #endregion SpecialistOf

        #region OwnerID
        protected SqlInt32 _OwnerID;
        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID

    }
}
