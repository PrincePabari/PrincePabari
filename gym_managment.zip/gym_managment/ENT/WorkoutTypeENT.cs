﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENT
{
    public class WorkoutTypeENT
    {
        #region WorkoutTypeID
        protected SqlInt32 _WorkoutTypeID;
        public SqlInt32 WorkoutTypeID
        {
            get
            {
                return _WorkoutTypeID;
            }
            set
            {
                _WorkoutTypeID = value;
            }
        }
        #endregion WorkoutID

        #region WorkoutType
        protected SqlString _WorkoutType;
        public SqlString WorkoutType
        {
            get
            {
                return _WorkoutType;
            }
            set
            {
                _WorkoutType = value;
            }

        }
        #endregion WorkoutType

        #region OwnerID
        protected SqlInt32 _OwnerID;
        public SqlInt32 OwnerID
        {
            get
            {
                return _OwnerID;
            }
            set
            {
                _OwnerID = value;
            }
        }
        #endregion OwnerID

        #region TrainerID
        protected SqlInt32 _TrainerID;
        public SqlInt32 TrainerID
        {
            get
            {
                return _TrainerID;
            }
            set
            {
                _TrainerID = value;
            }
        }
        #endregion TrainerID

        #region ClientID
        protected SqlInt32 _ClientID;
        public SqlInt32 ClientID
        {
            get
            {
                return _ClientID;
            }
            set
            {
                _ClientID = value;
            }
        }
        #endregion ClientID
    }
}
